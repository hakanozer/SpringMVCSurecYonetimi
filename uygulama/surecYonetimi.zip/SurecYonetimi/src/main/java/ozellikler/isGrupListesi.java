package ozellikler;

public class isGrupListesi {
	
	
	private String gid;
	private String iid;
	private String pid;
	private String iTarih;
	private String kid;
	private String kUnvan;
	private String kSeviye;
	private String kAdi;
	private String kSoyadi;
	private String kMail	;
	private String kTelefon;
	private String kAdres;
	private String kTarih;
	private String iAdi;
	private String gTarih;
	public String getGid() {
		return gid;
	}
	public void setGid(String gid) {
		this.gid = gid;
	}
	public String getIid() {
		return iid;
	}
	public void setIid(String iid) {
		this.iid = iid;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getiTarih() {
		return iTarih;
	}
	public void setiTarih(String iTarih) {
		this.iTarih = iTarih;
	}
	public String getKid() {
		return kid;
	}
	public void setKid(String kid) {
		this.kid = kid;
	}
	public String getkUnvan() {
		return kUnvan;
	}
	public void setkUnvan(String kUnvan) {
		this.kUnvan = kUnvan;
	}
	public String getkSeviye() {
		return kSeviye;
	}
	public void setkSeviye(String kSeviye) {
		this.kSeviye = kSeviye;
	}
	public String getkAdi() {
		return kAdi;
	}
	public void setkAdi(String kAdi) {
		this.kAdi = kAdi;
	}
	public String getkSoyadi() {
		return kSoyadi;
	}
	public void setkSoyadi(String kSoyadi) {
		this.kSoyadi = kSoyadi;
	}
	public String getkMail() {
		return kMail;
	}
	public void setkMail(String kMail) {
		this.kMail = kMail;
	}
	public String getkTelefon() {
		return kTelefon;
	}
	public void setkTelefon(String kTelefon) {
		this.kTelefon = kTelefon;
	}
	public String getkAdres() {
		return kAdres;
	}
	public void setkAdres(String kAdres) {
		this.kAdres = kAdres;
	}
	public String getkTarih() {
		return kTarih;
	}
	public void setkTarih(String kTarih) {
		this.kTarih = kTarih;
	}
	public String getiAdi() {
		return iAdi;
	}
	public void setiAdi(String iAdi) {
		this.iAdi = iAdi;
	}
	public String getgTarih() {
		return gTarih;
	}
	public void setgTarih(String gTarih) {
		this.gTarih = gTarih;
	}
	
	
	

}
