package ozellikler;

public class IstatistikOzellik {
	
	private String bitirilenisToplam;
	private String aktifisToplam;
	private String mesajToplam;
	private String gecenisToplam;
	
	
	public String getBitirilenisToplam() {
		return bitirilenisToplam;
	}
	public void setBitirilenisToplam(String bitirilenisToplam) {
		this.bitirilenisToplam = bitirilenisToplam;
	}
	public String getAktifisToplam() {
		return aktifisToplam;
	}
	public void setAktifisToplam(String aktifisToplam) {
		this.aktifisToplam = aktifisToplam;
	}
	public String getMesajToplam() {
		return mesajToplam;
	}
	public void setMesajToplam(String mesajToplam) {
		this.mesajToplam = mesajToplam;
	}
	public String getGecenisToplam() {
		return gecenisToplam;
	}
	public void setGecenisToplam(String gecenisToplam) {
		this.gecenisToplam = gecenisToplam;
	}

	
}
