package ozellikler;

public class mesajOzellik {
	
	private String sid;
	private String gonderenID;
	private String mesajText;
	private String gAdi;
	private String gSoyadi;
	private String aAdi;
	private String aSoyadi;
	private String mTarih;
	private String sesiID;
	
	public String getSid() {
		return sid;
	}
	public String getSesiID() {
		return sesiID;
	}
	public void setSesiID(String sesiID) {
		this.sesiID = sesiID;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public String getGonderenID() {
		return gonderenID;
	}
	public void setGonderenID(String gonderenID) {
		this.gonderenID = gonderenID;
	}
	public String getMesajText() {
		return mesajText;
	}
	public void setMesajText(String mesajText) {
		this.mesajText = mesajText;
	}
	public String getgAdi() {
		return gAdi;
	}
	public void setgAdi(String gAdi) {
		this.gAdi = gAdi;
	}
	public String getgSoyadi() {
		return gSoyadi;
	}
	public void setgSoyadi(String gSoyadi) {
		this.gSoyadi = gSoyadi;
	}
	public String getaAdi() {
		return aAdi;
	}
	public void setaAdi(String aAdi) {
		this.aAdi = aAdi;
	}
	public String getaSoyadi() {
		return aSoyadi;
	}
	public void setaSoyadi(String aSoyadi) {
		this.aSoyadi = aSoyadi;
	}
	public String getmTarih() {
		return mTarih;
	}
	public void setmTarih(String mTarih) {
		this.mTarih = mTarih;
	}
	
	
	
	

}
