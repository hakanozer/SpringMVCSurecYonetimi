package ozellikler;

public class RaporOzellik {
	
	private String sid;
	private String sBaslik;
	private String baslamaTarihi;
	private String bitisTarihi;
	private String sDurum;
	private String aAdi;
	private String aSoyadi;
	private String pAdi;
	private String pSoyadi;
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public String getsBaslik() {
		return sBaslik;
	}
	public void setsBaslik(String sBaslik) {
		this.sBaslik = sBaslik;
	}
	public String getBaslamaTarihi() {
		return baslamaTarihi;
	}
	public void setBaslamaTarihi(String baslamaTarihi) {
		this.baslamaTarihi = baslamaTarihi;
	}
	public String getBitisTarihi() {
		return bitisTarihi;
	}
	public void setBitisTarihi(String bitisTarihi) {
		this.bitisTarihi = bitisTarihi;
	}
	public String getsDurum() {
		return sDurum;
	}
	public void setsDurum(String sDurum) {
		this.sDurum = sDurum;
	}
	public String getaAdi() {
		return aAdi;
	}
	public void setaAdi(String aAdi) {
		this.aAdi = aAdi;
	}
	public String getaSoyadi() {
		return aSoyadi;
	}
	public void setaSoyadi(String aSoyadi) {
		this.aSoyadi = aSoyadi;
	}
	public String getpAdi() {
		return pAdi;
	}
	public void setpAdi(String pAdi) {
		this.pAdi = pAdi;
	}
	public String getpSoyadi() {
		return pSoyadi;
	}
	public void setpSoyadi(String pSoyadi) {
		this.pSoyadi = pSoyadi;
	}
	
	

}
