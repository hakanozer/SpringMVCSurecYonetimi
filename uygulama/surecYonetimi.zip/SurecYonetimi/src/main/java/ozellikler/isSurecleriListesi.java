package ozellikler;

public class isSurecleriListesi {

	
	private String sid;
	private String kid;
	private String pid;
	private String sBaslik;
	private String sAciklama;
	private String baslamaTarihi;
	private String bitisTarihi;
	private String sDurum;
	
	// i�i atayan
	private String akid;
	private String akUnvan;
	private String akSeviye;
	private String akAdi;
	private String akSoyadi;
	private String akMail;
	private String akTelefon;
	private String akAdres;
	private String akTarih;
	
	// i�i alan
	private String ckid;
	private String ckUnvan;
	private String ckSeviye;
	private String ckAdi;
	private String ckSoyadi;
	private String ckMail;
	private String ckTelefon;
	private String ckAdres;
	private String ckTarih;
	
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public String getKid() {
		return kid;
	}
	public void setKid(String kid) {
		this.kid = kid;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getsBaslik() {
		return sBaslik;
	}
	public void setsBaslik(String sBaslik) {
		this.sBaslik = sBaslik;
	}
	public String getsAciklama() {
		return sAciklama;
	}
	public void setsAciklama(String sAciklama) {
		this.sAciklama = sAciklama;
	}
	public String getBaslamaTarihi() {
		return baslamaTarihi;
	}
	public void setBaslamaTarihi(String baslamaTarihi) {
		this.baslamaTarihi = baslamaTarihi;
	}
	public String getBitisTarihi() {
		return bitisTarihi;
	}
	public void setBitisTarihi(String bitisTarihi) {
		this.bitisTarihi = bitisTarihi;
	}
	public String getsDurum() {
		return sDurum;
	}
	public void setsDurum(String sDurum) {
		this.sDurum = sDurum;
	}
	public String getAkid() {
		return akid;
	}
	public void setAkid(String akid) {
		this.akid = akid;
	}
	public String getAkUnvan() {
		return akUnvan;
	}
	public void setAkUnvan(String akUnvan) {
		this.akUnvan = akUnvan;
	}
	public String getAkSeviye() {
		return akSeviye;
	}
	public void setAkSeviye(String akSeviye) {
		this.akSeviye = akSeviye;
	}
	public String getAkAdi() {
		return akAdi;
	}
	public void setAkAdi(String akAdi) {
		this.akAdi = akAdi;
	}
	public String getAkSoyadi() {
		return akSoyadi;
	}
	public void setAkSoyadi(String akSoyadi) {
		this.akSoyadi = akSoyadi;
	}
	public String getAkMail() {
		return akMail;
	}
	public void setAkMail(String akMail) {
		this.akMail = akMail;
	}
	public String getAkTelefon() {
		return akTelefon;
	}
	public void setAkTelefon(String akTelefon) {
		this.akTelefon = akTelefon;
	}
	public String getAkAdres() {
		return akAdres;
	}
	public void setAkAdres(String akAdres) {
		this.akAdres = akAdres;
	}
	public String getAkTarih() {
		return akTarih;
	}
	public void setAkTarih(String akTarih) {
		this.akTarih = akTarih;
	}
	public String getCkid() {
		return ckid;
	}
	public void setCkid(String ckid) {
		this.ckid = ckid;
	}
	public String getCkUnvan() {
		return ckUnvan;
	}
	public void setCkUnvan(String ckUnvan) {
		this.ckUnvan = ckUnvan;
	}
	public String getCkSeviye() {
		return ckSeviye;
	}
	public void setCkSeviye(String ckSeviye) {
		this.ckSeviye = ckSeviye;
	}
	public String getCkAdi() {
		return ckAdi;
	}
	public void setCkAdi(String ckAdi) {
		this.ckAdi = ckAdi;
	}
	public String getCkSoyadi() {
		return ckSoyadi;
	}
	public void setCkSoyadi(String ckSoyadi) {
		this.ckSoyadi = ckSoyadi;
	}
	public String getCkMail() {
		return ckMail;
	}
	public void setCkMail(String ckMail) {
		this.ckMail = ckMail;
	}
	public String getCkTelefon() {
		return ckTelefon;
	}
	public void setCkTelefon(String ckTelefon) {
		this.ckTelefon = ckTelefon;
	}
	public String getCkAdres() {
		return ckAdres;
	}
	public void setCkAdres(String ckAdres) {
		this.ckAdres = ckAdres;
	}
	public String getCkTarih() {
		return ckTarih;
	}
	public void setCkTarih(String ckTarih) {
		this.ckTarih = ckTarih;
	}
	
	
	
	
	
}
